import * as React from "react";
import { PropertyControls, ControlType } from "framer";
import axios from "axios";

//lets install and import axios for the http requests -> In File > Show Package

// Define type of property
interface Props {
  text: string;
}

export class test extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: "Hello World!"
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: "Text" }
  };

  //lets setup some states
  states = {
    countries: ""
  };

  //lets make a http request.
  // to bypass this error let use this website -
  componentDidMount() {
    let URL = `${"https://cors-anywhere.herokuapp.com/"}https://listsdesign.herokuapp.com/lists/countries.json`;
    axios.get(URL).then(data => {
      let randomNum = Math.floor(Math.random() * 99);
      console.log(data.data.Countries[randomNum].data);
      //console is showing an array...100 in number. lets check the first array
      //to get a random country everytime we have to generate a random number in between //0-100 everytime this is rendered.
      // we need to now render this in framer...
      this.setState({ countries: data.data.Countries[randomNum].data });
    });
  }

  render() {
    let { countries } = this.state;
    return <div style={{}}>{countries}</div>;
  }
}
