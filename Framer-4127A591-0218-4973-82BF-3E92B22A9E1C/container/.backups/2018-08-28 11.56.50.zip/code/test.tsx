import * as React from "react";
import { PropertyControls, ControlType } from "framer";
import axios from "axios";

//lets install and import axios for the http requests -> In File > Show Package

// Define type of property
interface Props {
  text: string;
}

export class test extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: "Hello World!"
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: "Text" }
  };

  //lets make a http request.
  // to bypass this error let use this website -
  componentDidMount() {
    let URL = `${"https://cors-anywhere.herokuapp.com/"}https://listsdesign.herokuapp.com/lists/countries.json`;
    axios.get(URL).then(data => {
      console.log(data.data.Countries[0].data);
      //console is showing an array...100 in number. lets check the first array
    });
  }

  render() {
    return <div style={{}}>{this.props.text}</div>;
  }
}
