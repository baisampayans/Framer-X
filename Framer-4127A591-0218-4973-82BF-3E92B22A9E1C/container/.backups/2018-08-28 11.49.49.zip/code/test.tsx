import * as React from "react";
import { PropertyControls, ControlType } from "framer";

// Define type of property
interface Props {
  text: string;
}

export class test extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: "Hello World!"
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: "Text" }
  };

  render() {
    return <div style={{}}>{this.props.text}</div>;
  }
}
